import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BillinginformationPage } from './billinginformation';

@NgModule({
  declarations: [
    BillinginformationPage,
  ],
  imports: [
    IonicPageModule.forChild(BillinginformationPage),
  ],
})
export class BillinginformationPageModule {}
