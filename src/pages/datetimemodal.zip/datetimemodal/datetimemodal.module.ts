import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DatetimemodalPage } from './datetimemodal';

@NgModule({
  declarations: [
    DatetimemodalPage,
  ],
  imports: [
    IonicPageModule.forChild(DatetimemodalPage),
  ],
})
export class DatetimemodalPageModule {}
