var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Appsetting } from "../../providers/appsetting";
import { Http, Headers, RequestOptions } from '@angular/http';
import { ToastController, AlertController, LoadingController, Events } from 'ionic-angular';
/**
 * Generated class for the ReviewsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
var ReviewsPage = /** @class */ (function () {
    function ReviewsPage(navCtrl, navParams, events, toastCtrl, appsetting, http, alertCtrl, loadingCtrl) {
        this.navCtrl = navCtrl;
        this.navParams = navParams;
        this.events = events;
        this.toastCtrl = toastCtrl;
        this.appsetting = appsetting;
        this.http = http;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.data = [];
        this.parkingdata = [];
        console.log(this.navParams.data);
        this.parkingdata = this.navParams.data;
    }
    ReviewsPage.prototype.onModelChange = function (number) {
        console.log(number);
        this.rating = number;
    };
    ReviewsPage.prototype.postdata = function () {
        var _this = this;
        console.log(this.data.comment);
        var headers = new Headers();
        headers.append('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
        var options = new RequestOptions({ headers: headers });
        var userid = JSON.parse(localStorage.getItem('UserDetailcustomer'))._id;
        var postdata = {
            parking_id: this.parkingdata._id,
            user_id: userid,
            review: this.data.comment,
            rating: this.rating
        };
        //alert(this.devicetoken)
        console.log(postdata);
        var Serialized = this.serializeObj(postdata);
        var Loading = this.loadingCtrl.create({
            spinner: 'bubbles',
            cssClass: 'loader',
            content: "Loading",
            dismissOnPageChange: true
        });
        Loading.present().then(function () {
            _this.http.post(_this.appsetting.myGlobalVar + 'users/AddReviewRating', Serialized, options).map(function (res) { return res.json(); }).subscribe(function (response) {
                console.log(response);
                Loading.dismiss();
            });
        });
    };
    ReviewsPage.prototype.serializeObj = function (obj) {
        var result = [];
        for (var property in obj)
            result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));
        return result.join("&");
    };
    ReviewsPage.prototype.ionViewDidLoad = function () {
        console.log('ionViewDidLoad ReviewsPage');
    };
    ReviewsPage = __decorate([
        IonicPage(),
        Component({
            selector: 'page-reviews',
            templateUrl: 'reviews.html',
        }),
        __metadata("design:paramtypes", [NavController, NavParams,
            Events,
            ToastController,
            Appsetting,
            Http,
            AlertController,
            LoadingController])
    ], ReviewsPage);
    return ReviewsPage;
}());
export { ReviewsPage };
//# sourceMappingURL=reviews.js.map