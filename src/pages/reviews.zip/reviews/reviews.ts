import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Ionic2RatingModule } from 'ionic2-rating';
import { Appsetting } from "../../providers/appsetting";
import { HomePage } from '../home/home';
import { Http, Headers, RequestOptions } from '@angular/http';
import { ToastController, AlertController, LoadingController,ActionSheetController,Events} from 'ionic-angular';
/**
 * Generated class for the ReviewsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reviews',
  templateUrl: 'reviews.html',
})
export class ReviewsPage {
rating:any;
data:any=[];
parkingdata:any=[];
  constructor(public navCtrl: NavController, public navParams: NavParams,
    public events: Events,
  public toastCtrl: ToastController,
  public appsetting: Appsetting,
  public http: Http,
  public alertCtrl: AlertController,
  public loadingCtrl: LoadingController) {
      console.log(this.navParams.data);
      this.parkingdata = this.navParams.data;
  }
  onModelChange(number){
      console.log(number);
      this.rating = number;
     
  }
  postdata(){
      console.log(this.data.comment);
       let headers = new Headers();
headers.append('Content-Type', 'application/x-www-form-urlencoded;charset=utf-8');
let options = new RequestOptions({ headers: headers });
 var userid = JSON.parse(localStorage.getItem('UserDetailcustomer'))._id;
var postdata = {
  parking_id:this.parkingdata._id,
user_id:userid,
review:this.data.comment,
rating: this.rating
}
//alert(this.devicetoken)
console.log(postdata);
var Serialized = this.serializeObj(postdata);
    var Loading = this.loadingCtrl.create({
     spinner: 'bubbles',
        cssClass: 'loader',
        content: "Loading",
dismissOnPageChange:true
    });
    Loading.present().then(() => {
      this.http.post(this.appsetting.myGlobalVar + 'users/AddReviewRating', Serialized, options).map(res => res.json()).subscribe(response => {
        console.log(response);
        
        Loading.dismiss();
        })
        })
  }
      serializeObj(obj) {
      var result = [];
      for (var property in obj)
        result.push(encodeURIComponent(property) + "=" + encodeURIComponent(obj[property]));

      return result.join("&");
    }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ReviewsPage');
  }

}
